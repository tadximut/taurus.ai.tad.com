🪐 TAURUS - AI Chat App
━━━━━━━━━━━━━━━━━━━━━━━
📦 Struktur Folder:
├── AndroidManifest.xml
├── assets/config.json           → API Key Gemini
├── data/chat/sessions_01.ai    → File obrolan
├── res/
│   ├── layout/activity_main.xml → UI utama
│   └── drawable/                → background.xml, input_box.xml, button.xml
├── smali/com/taurus/           → MainActivity.smali & FileHelper.smali
└── readme.txt                   → Info ini

🔑 API:
• Menggunakan Gemini-Pro API (Google AI)
• API Key disimpan aman di `assets/config.json`

🧠 Fitur:
• Chat mirip ChatGPT
• Bisa obrolan baru
• Riwayat tersimpan otomatis
• Tema abu-abu gelap/putih

📄 Note:
• Semua pesan disimpan di `data/chat/`
• Bisa build APK langsung via MT Manager

🚀 Dibuat dengan cinta pakai MT Manager + tangan anak bangsa 💪